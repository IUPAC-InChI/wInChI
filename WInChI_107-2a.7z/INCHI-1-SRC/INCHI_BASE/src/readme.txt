The sub-directory 'src' contains C source files of common codebase
which is used by both InChI Library and inchi-1 executable.

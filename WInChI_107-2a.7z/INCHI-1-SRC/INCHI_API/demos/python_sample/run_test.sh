# Use Python 3
python3 mol2inchi.py -i test1.sdf -k >test1.out

This directory contains examples of InChI API usage, for C 
('inchi_main', 'mol2inchi', 'test_ixa'); see projects 
for MS Visual Studio 2015 in 'vc14' and for gcc/Linux 
in 'gcc' subdirs) and Python 3 ('python_sample'). 

Note that all the projects in addition to corresponding
demo executable create also a necessary 'libinchi' library  
(.dll or .so) in the same upper-level directory 'bin' or 'bin2'.

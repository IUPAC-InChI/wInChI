This directory contains example of using "classic" InChI API.

The source codes are placed in sub-directory 'src';
gcc/Linux makefiles in sub-directory 'gcc';
MS VS 2015 project is placed in sub-directory 'vc14'.

The created binaries are saved in upper-level directory 'bin' or 'bin2'.

This directory contains example of using API function MakeINCHIFromMolfileText().

The source codes are placed in sub-directory 'src';
gcc/Linux makefiles in sub-directory 'gcc';
MS VS 2015 project is placed in sub-directory 'vc14'.

The created binaries are saved in upper-level directory 'bin' or 'bin2'.

The light-weight demo program mol2inchi reads input Molfile/SDFile and 
generates InChI directly from that texts, bypassing creation of separate
internal data structures holding molecules.

This directory contains example of using Extensible InChI API (IXA).

The demo program test_ixa reads input Molfile/SDFile and 
generates InChI; it also demonstrates an organization  of
verification round-trip "Structure->InChI->Structure->InChI"
via InChI API calls.

The source codes are placed in sub-directory 'src';
gcc/Linux makefiles in sub-directory 'gcc';
MS VS 2015 project is placed in sub-directory 'vc14'.

The precompiled binaries are saved in upper-level directory 'bin' or bin2'.
